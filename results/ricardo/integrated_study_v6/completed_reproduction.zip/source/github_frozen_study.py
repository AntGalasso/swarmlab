#!/usr/bin/env python3
"""Run the existing frozen study on GitHub and publish restartable checkpoints.

Only orchestration changes: experiment source, cache keys, outcomes and analysis
stay frozen. The repository secret is consumed once and kept in memory.
"""
from __future__ import annotations

import argparse
import base64
import contextlib
import datetime as dt
import fcntl
import hashlib
import io
import itertools
import json
import os
import re
import shutil
import signal
import sqlite3
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from types import SimpleNamespace

import budget_study as driver
import budget_study_analysis as analysis
import overnight_frozen_study as previous

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results/ricardo/integrated_study_v6'
ARCHIVE = ROOT / 'recovery/h2h3-latest.zip'
MANIFEST = ROOT / 'recovery/h2h3-latest.json'
REPOSITORY = 'ricardofitas/swarm-adaption-hackathon'
BRANCH = 'ricardo/team-consolidated-20261106'
MAX_GITHUB_STARTS_PER_PHASE = 2
STATE = {'status': 'starting', 'execution_environment': 'github_actions'}
STATE_LOCK = threading.RLock()
PUBLISH_LOCK = threading.Lock()
STOP = threading.Event()
PUBLICATION_FAILURE = threading.Event()
CONSOLE = sys.stdout


def utc():
    return dt.datetime.now(dt.UTC).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    os.replace(temp, path)


def events(path):
    return [json.loads(s) for s in path.read_text().splitlines() if s.strip()] if path.exists() else []


def validate():
    previous.OUT = OUT
    previous.validate_source()
    plan = json.loads((OUT / 'frozen_protocol.json').read_text())
    for phase in ('main', 'heldout'):
        rows = events(OUT / phase / 'episodes.jsonl')
        seeds = plan['main_seeds' if phase == 'main' else 'heldout_seeds']
        expected = set(itertools.product(plan['topologies'], seeds, plan['regimes'], plan['arms']))
        keys = [(r['topology'], r['seed'], r['regime'], r['policy']) for r in rows]
        if len(set(keys)) != len(keys) or not set(keys) <= expected:
            raise RuntimeError('Duplicate or unexpected completed episode in ' + phase)
        if any(r['fake'] or r['model'] != plan['model'] or r['attack_free_control']
               or r['budget_violations'] or r['enforcement_spend'] > 12 + 1e-9 for r in rows):
            raise RuntimeError('Invalid completed episode in ' + phase)
    anchor = json.loads((OUT / 'github_migration.json').read_text())
    prefix = (OUT / 'main/episodes.jsonl').read_bytes()[:anchor['preserved_main_prefix_bytes']]
    if digest(prefix) != anchor['preserved_main_prefix_sha256']:
        raise RuntimeError('The original 78-episode prefix changed.')
    return plan


def heartbeat(status=None, **extra):
    with STATE_LOCK:
        if status is not None:
            STATE.update(status=status, **extra)
        value = dict(STATE, updated_utc=utc(), main_completed=previous.rows('main'),
                     main_total=240, heldout_completed=previous.rows('heldout'), heldout_total=120,
                     source_frozen=True, credential_storage='process_memory_only')
        atomic_json(OUT / 'github_heartbeat.json', value)
        atomic_json(OUT / 'pipeline_receipt.json', value)
    print(json.dumps(value, sort_keys=True), file=CONSOLE, flush=True)
    return value


def safe_file(path):
    data = path.read_bytes()
    if path.suffix == '.jsonl':
        if data and not data.endswith(b'\n'):
            data = data[:data.rfind(b'\n') + 1]
        for line in data.splitlines():
            if line.strip():
                json.loads(line)
    elif path.suffix == '.json':
        json.loads(data)
    if re.search(rb'pt_live_[A-Za-z0-9_\-]{12,}|github_pat_[A-Za-z0-9_]{12,}|gh[pousr]_[A-Za-z0-9]{20,}', data):
        raise RuntimeError('Credential pattern detected; refusing checkpoint publication.')
    return data


def snapshot():
    """Capture JSONL prefixes first and SQLite backups after them, without WAL files."""
    validate()
    files = {}
    for path in sorted(OUT.rglob('*')):
        if not path.is_file() or path.suffix in ('.zip', '.lock', '.tmp') or path.name == 'github_snapshot_members.json':
            continue
        if path.name.endswith(('-wal', '-shm')) or path.suffix == '.sqlite':
            continue
        files[str(path.relative_to(OUT))] = safe_file(path)
    with tempfile.TemporaryDirectory(prefix='h2h3-sqlite-') as directory:
        for path in sorted(OUT.rglob('*.sqlite')):
            target = Path(directory) / (digest(str(path).encode()) + '.sqlite')
            source = sqlite3.connect('file:' + str(path) + '?mode=ro', uri=True, timeout=30)
            destination = sqlite3.connect(target)
            try:
                source.backup(destination)
                if destination.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                    raise RuntimeError('SQLite checkpoint integrity failure.')
            finally:
                destination.close()
                source.close()
            files[str(path.relative_to(OUT))] = safe_file(target)
    members = {name: digest(data) for name, data in files.items()}
    files['github_snapshot_members.json'] = (json.dumps(members, sort_keys=True, indent=2) + '\n').encode()
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in files.items():
            archive.writestr(name, data)
    data = buffer.getvalue()
    state = json.loads(files['pipeline_receipt.json'])
    meta = {'schema': 1, 'captured_utc': utc(), 'archive_sha256': digest(data),
            'main_completed': len(files.get('main/episodes.jsonl', b'').splitlines()),
            'heldout_completed': len(files.get('heldout/episodes.jsonl', b'').splitlines()),
            'phase_credit_cap': previous.PHASE_CREDIT_CAP,
            'max_github_starts_per_phase': MAX_GITHUB_STARTS_PER_PHASE,
            'state': state, 'source_sha256': driver.source_hashes(),
            'analysis_sha256': analysis.digest(ROOT / 'budget_study_analysis.py')}
    return data, meta, files


def restore():
    data = ARCHIVE.read_bytes()
    meta = json.loads(MANIFEST.read_text())
    if digest(data) != meta['archive_sha256']:
        raise RuntimeError('Checkpoint archive hash mismatch.')
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names = archive.namelist()
        if len(set(names)) != len(names) or any(Path(n).is_absolute() or '..' in Path(n).parts for n in names):
            raise RuntimeError('Unsafe checkpoint archive.')
        hashes = json.loads(archive.read('github_snapshot_members.json'))
        if set(names) != set(hashes) | {'github_snapshot_members.json'}:
            raise RuntimeError('Checkpoint member list mismatch.')
        if any(digest(archive.read(name)) != sha for name, sha in hashes.items()):
            raise RuntimeError('Checkpoint member hash mismatch.')
        with tempfile.TemporaryDirectory(prefix='h2h3-restore-', dir=OUT.parent) as directory:
            archive.extractall(directory)
            if OUT.exists():
                shutil.rmtree(OUT)
            shutil.copytree(directory, OUT)
    validate()
    return meta


class Publisher:
    def __init__(self, token):
        self.token = token

    def request(self, path, value=None, method=None):
        payload = json.dumps(value).encode() if value is not None else None
        request = urllib.request.Request('https://api.github.com/repos/' + REPOSITORY + '/' + path,
                    data=payload, method=method,
                    headers={'Authorization': 'Bearer ' + self.token,
                             'Accept': 'application/vnd.github+json',
                             'Content-Type': 'application/json', 'User-Agent': 'frozen-h2h3-checkpoint'})
        try:
            with urllib.request.urlopen(request, timeout=60) as response:  # noqa: S310 -- fixed GitHub HTTPS origin
                return json.load(response)
        except urllib.error.HTTPError as exc:
            raise RuntimeError('GitHub checkpoint HTTP ' + str(exc.code)) from None

    def publish(self):
        with PUBLISH_LOCK:
            data, meta, files = snapshot()
            ref = self.request('git/ref/heads/' + BRANCH)
            parent = ref['object']['sha']
            commit = self.request('git/commits/' + parent)
            payloads = {'recovery/h2h3-latest.zip': data,
                        'recovery/h2h3-latest.json': (json.dumps(meta, indent=2, sort_keys=True) + '\n').encode(),
                        'results/ricardo/integrated_study_v6/pipeline_receipt.json': files['pipeline_receipt.json'],
                        'results/ricardo/integrated_study_v6/github_heartbeat.json': files['github_heartbeat.json']}
            for phase in ('main', 'heldout'):
                name = phase + '/episodes.jsonl'
                if name in files:
                    payloads['results/ricardo/integrated_study_v6/' + name] = files[name]
            entries = []
            for path, content in payloads.items():
                blob = self.request('git/blobs', {'content': base64.b64encode(content).decode(), 'encoding': 'base64'})
                entries.append({'path': path, 'mode': '100644', 'type': 'blob', 'sha': blob['sha']})
            tree = self.request('git/trees', {'base_tree': commit['tree']['sha'], 'tree': entries})
            title = (f"Checkpoint frozen H2/H3: {meta['main_completed']}/240 main, "
                     f"{meta['heldout_completed']}/120 heldout ({meta['state']['status']})")
            result = self.request('git/commits', {'message': title, 'tree': tree['sha'], 'parents': [parent]})
            self.request('git/refs/heads/' + BRANCH, {'sha': result['sha'], 'force': False}, 'PATCH')
            print(json.dumps({'checkpoint_commit': result['sha'], 'main': meta['main_completed'],
                              'heldout': meta['heldout_completed'], 'archive_sha256': meta['archive_sha256']}), file=CONSOLE, flush=True)


def watch(publisher):
    ticks = 0
    while not STOP.wait(30):
        heartbeat()
        ticks += 1
        if ticks % 4 == 0:
            try:
                publisher.publish()
            except Exception as exc:
                PUBLICATION_FAILURE.set()
                heartbeat('blocked_checkpoint', error_type=type(exc).__name__,
                          error=str(exc) if isinstance(exc, RuntimeError) else type(exc).__name__)
                os.kill(os.getpid(), signal.SIGTERM)
                return


def run_phase(phase, baseline, publisher):
    receipt = previous.read_json(OUT / phase / 'latest_receipt.json')
    if receipt and receipt['status'] == 'completed':
        return
    starts = [e for e in events(OUT / 'github_attempts.jsonl') if e['event'] == 'started' and e['phase'] == phase]
    while len(starts) < MAX_GITHUB_STARTS_PER_PHASE:
        validate()
        remaining = previous.allowance(phase, baseline)
        start = {'utc': utc(), 'phase': phase, 'event': 'started', 'github_attempt': len(starts) + 1,
                 'attempt': previous.attempts(phase) + 1, 'execution_environment': 'github_actions',
                 'episodes_before': previous.rows(phase), 'remaining_credit_allowance': remaining,
                 'authorization': 'User requested GitHub continuation after adding the repository secret.'}
        driver.append(OUT / 'github_attempts.jsonl', start)
        driver.append(OUT / 'overnight_attempts.jsonl', start)
        starts.append(start)
        heartbeat('running_' + phase, phase=phase, github_attempt=len(starts))
        publisher.publish()
        try:
            with (OUT / 'github_execution.log').open('a', buffering=1) as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
                driver.run_phase(SimpleNamespace(phase=phase, allow_live_llm=True, prompt_key=True,
                                 max_credits=remaining, confirm_frozen_analysis=phase == 'heldout'), OUT)
            return
        except RuntimeError as exc:
            safe = str(exc)
            transient = any(term in safe for term in ('HTTP 429', 'HTTP 500', 'HTTP 502', 'HTTP 503',
                            'HTTP 504', 'APITimeoutError', 'APIConnectionError'))
            driver.append(OUT / 'github_attempts.jsonl', {'utc': utc(), 'event': 'failed',
                          'phase': phase, 'github_attempt': len(starts), 'error': safe, 'transient': transient})
            heartbeat('waiting_to_retry_' + phase if transient and len(starts) < MAX_GITHUB_STARTS_PER_PHASE else 'blocked', error=safe)
            publisher.publish()
            if not transient or len(starts) >= MAX_GITHUB_STARTS_PER_PHASE:
                raise
            time.sleep(60)
    raise RuntimeError('GitHub phase recovery allowance exhausted; preserve all attempts.')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--validate-only', action='store_true')
    ap.add_argument('--restore-only', action='store_true')
    args = ap.parse_args()
    if args.validate_only:
        validate()
        print(json.dumps({'source_verified': True, 'main': previous.rows('main'),
                          'heldout': previous.rows('heldout'), 'remaining_main_credits':
                          previous.allowance('main', previous.read_json(OUT / 'overnight_recovery_checkpoint.json'))}))
        return
    restore()
    if args.restore_only:
        print('CHECKPOINT_RESTORED_AND_VERIFIED')
        return
    key = os.environ.pop('ADAPTION_API_KEY', '').strip()
    token = os.environ.pop('GITHUB_TOKEN', '').strip()
    if not key or not token:
        raise RuntimeError('Missing GitHub runtime credentials; no study request sent.')
    driver.getpass.getpass = lambda _: key
    publisher = Publisher(token)
    lock = (OUT / 'overnight_writer.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if any(previous.another_cache_connection(p) for p in ('main', 'heldout')):
        raise RuntimeError('Another study cache connection is active.')
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(SystemExit(143)))
    signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(RuntimeError('GitHub runtime bound reached.')))
    signal.alarm(5 * 3600)
    heartbeat('ready', started_utc=utc(), run_id=os.getenv('GITHUB_RUN_ID'),
              run_attempt=os.getenv('GITHUB_RUN_ATTEMPT'))
    baseline = previous.read_json(OUT / 'overnight_recovery_checkpoint.json')
    thread = threading.Thread(target=watch, args=(publisher,), daemon=True)
    try:
        publisher.publish()
        thread.start()
        for phase in ('main', 'heldout'):
            run_phase(phase, baseline, publisher)
            heartbeat('analyzing_' + phase)
            analysis.analyze(OUT, phase)
            publisher.publish()
        validate()
        heartbeat('completed', note='Both frozen phases and separate analyses are complete; manuscript review follows.')
    except BaseException as exc:
        heartbeat('blocked', error_type=type(exc).__name__,
                  error=str(exc) if isinstance(exc, (RuntimeError, ValueError)) else type(exc).__name__)
        raise
    finally:
        STOP.set()
        signal.alarm(0)
        if thread.is_alive():
            thread.join(timeout=90)
        try:
            publisher.publish()
        except Exception as exc:
            print(json.dumps({'final_checkpoint_error': type(exc).__name__}), flush=True)
        if previous.rows('main') == 240 and previous.rows('heldout') == 120:
            target = OUT / 'completed_reproduction.zip'
            data, _, _ = snapshot()
            with zipfile.ZipFile(io.BytesIO(data)) as source, zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
                for name in source.namelist():
                    archive.writestr(name, source.read(name))
                for name in (*driver.SOURCE_FILES, 'budget_study_analysis.py', 'github_frozen_study.py'):
                    archive.write(ROOT / name, 'source/' + name)


if __name__ == '__main__':
    main()
