# Fixed observability extension

CPU only; original BA and LLM results are preserved. The two fixed graphs are
small-world and star-hub. Read `PROTOCOL.md` and `DECISIONS.json` for scope,
unblinded status, row counts and the two-contrast analysis family.

From the repository/workspace root, with the pinned native runtime and source on
`PYTHONPATH`:

```bash
python bazt_headline/observability_extension/run_extension.py calibration native_mock
python bazt_headline/observability_extension/run_extension.py calibration paid_only
python bazt_headline/observability_extension/run_extension.py validate-calibration
python bazt_headline/observability_extension/run_extension.py evaluation native_mock
python bazt_headline/observability_extension/run_extension.py evaluation paid_only
python bazt_headline/observability_extension/analyze_extension.py
```

Both calibration modes must pass before either evaluation. Each evaluation is
12,960 rows, for 25,920 combined. The two graphs are never pooled or selected.
Outputs are confined to this package's `results_20261107/` folder and native
checkpoints support identical-source resumption.

Tests:

```bash
python -m unittest discover -v -s bazt_headline/observability_extension -p 'test_*.py'
```
