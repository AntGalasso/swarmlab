import copy
import dataclasses
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import torch
import run_extension as r
import analyze_extension as a
from bazt_lab.core import public as core
from bazt_lab.features.mock_engine.public import MockPlatform
from bazt_lab.features.runner.public import unit_id
from test_native_engine import equal


def cells(mode):
    return [dict(arm=arm, topology=topo, agents=12,
                 thresholds={k: 1. for k in r.contract.expected_statistics(arm, mode)},
                 diagnostics=dict(mode='closed_loop', passes=2, rate=.02, within_tolerance=True))
            for arm in r.contract.ARMS[1:] for topo in r.GRAPHS]


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.s = core.load_settings(r.SETTINGS)

    def test_exact_fixed_grid_and_mode_unit_identity(self):
        grid = list(r.settings_gate(self.s))
        self.assertEqual(len(grid), 12960)
        self.assertEqual({u['topology'] for u in grid}, set(r.GRAPHS))
        self.assertEqual({u['seed'] for u in grid}, set(range(742001, 742031)))
        self.assertEqual({u['sink'] for u in grid}, set(range(12)))
        self.assertEqual(len({unit_id(u) for u in grid}), len(grid))
        for graph in r.GRAPHS:
            self.assertEqual(sum(u['topology'] == graph for u in grid), 6480)
        self.assertFalse(any(u['arm'] == 'A' and u['audit'] != 'uncapped' for u in grid))

    def test_gate_requires_eight_cells_finite_keys_ceiling_and_retains_flags(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'thresholds.json'
            data = dict(alpha=.02, cells=cells('paid_only'))
            data['cells'][-1]['diagnostics'].update(rate=.013, within_tolerance=False)
            p.write_text(json.dumps(data))
            self.assertEqual(len(r.calibration_gate(p, 'paid_only')['flagged']), 1)
            for bad in ('missing', 'duplicate', 'over', 'wrong_statistics'):
                value = copy.deepcopy(data)
                if bad == 'missing': value['cells'].pop()
                elif bad == 'duplicate': value['cells'][-1] = copy.deepcopy(value['cells'][0])
                elif bad == 'over': value['cells'][0]['diagnostics']['rate'] = .023
                else: value['cells'][0]['thresholds'] = {'unobserved': 1.}
                p.write_text(json.dumps(value))
                with self.subTest(bad=bad), self.assertRaises(RuntimeError):
                    r.calibration_gate(p, 'paid_only')

    def test_control_calibration_compares_each_graph(self):
        old = r.OUTPUT
        with tempfile.TemporaryDirectory() as d:
            try:
                r.OUTPUT = Path(d)
                for mode in r.contract.MODES:
                    r.write_json(r.threshold_path('calibration', mode), dict(alpha=.02, cells=cells(mode)))
                self.assertEqual(len(r.compare_calibrations()), 2)
                p = r.threshold_path('calibration', 'paid_only')
                data = json.loads(p.read_text())
                next(c for c in data['cells'] if c['arm'] == 'C' and c['topology'] == 'star_hub')['thresholds']['rl_minus_ts'] = 2.
                p.write_text(json.dumps(data))
                with self.assertRaises(RuntimeError): r.compare_calibrations()
            finally:
                r.OUTPUT = old

    def test_analysis_sources_are_frozen_and_drift_is_refused(self):
        record = r.extension_identity('calibration')
        self.assertIn('analyze_extension.py', record['source_sha256'])
        self.assertIn('analyze_mock.py', record['reused_helpers_sha256'])
        old = r.OUTPUT
        with tempfile.TemporaryDirectory() as d:
            try:
                r.OUTPUT = Path(d)
                target = r.OUTPUT / 'calibration' / 'paid_only' / 'EXTENSION_FREEZE.json'
                r.write_json(target, record)
                self.assertEqual(r.verify_frozen('calibration', 'paid_only'), record)
                record['source_sha256']['analyze_extension.py'] = 'changed'
                r.write_json(target, record)
                with self.assertRaises(RuntimeError): r.verify_frozen('calibration', 'paid_only')
            finally:
                r.OUTPUT = old

    def test_topologies_are_not_pooled_and_same_victim_endpoint(self):
        rows = {}
        for graph, value in [('small_world', .5), ('star_hub', .8)]:
            for sink in range(12):
                rows[graph + str(sink)] = dict(topology=graph, seed=742001, arm='C', audit=.1,
                    intervention=.1, attack='insider_pi', sink=sink, asr_final=value,
                    accuracy_clean_reference=.9, accuracy_clean=.1)
        x = a.graph_vector(rows, 'small_world', [742001], ['C'], .1, 'excess_error')
        self.assertAlmostEqual(x[0, 0], .4)
        y = a.graph_vector(rows, 'star_hub', [742001], ['C'], .1, 'excess_error')
        self.assertAlmostEqual(y[0, 0], .7)

    def test_two_fixed_tests_have_holm_family_two(self):
        vals = a.holm2([dict(p_two_sided=.04), dict(p_two_sided=.01)])
        self.assertEqual([x['p_holm_two_graphs'] for x in vals], [.04, .02])


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.s = core.load_settings(r.SETTINGS)
        self.grid = list(r.settings_gate(self.s))
        self.platform = MockPlatform()

    def unit(self, graph, arm, attack='insider_pi'):
        u = copy.deepcopy(next(u for u in self.grid if u['topology'] == graph and u['arm'] == arm
                               and u['sink'] == 0 and u['attack'] == attack and u['audit'] == 'uncapped'))
        u.update(id=unit_id(u))
        if attack != 'none': u['twin_id'] = unit_id({**u, 'attack': 'none'})
        return u

    def test_actual_engine_negative_controls_on_both_graphs(self):
        for graph in r.GRAPHS:
            for arm, thresholds in [('A', {}), ('B', {'judge': 1.}), ('C', {'rl_minus_ts': 0.})]:
                traces = []
                for mode in r.contract.MODES:
                    u = self.unit(graph, arm)
                    u['thresholds'] = thresholds
                    spec = r.contract.build_wiring(mode).arm(arm)
                    traces.append(list(self.platform._simulate_chunk([u], spec, self.s, 2., with_clean=True)))
                for (_, ta, _), (_, tb, _) in zip(*traces):
                    for field in dataclasses.fields(ta):
                        if field.name != 'meta': equal(self, getattr(ta, field.name), getattr(tb, field.name))
                    ra, rb = self.platform._rows(ta, self.s), self.platform._rows(tb, self.s)
                    self.assertEqual([a.old.scientific_row(x) for x in ra], [a.old.scientific_row(x) for x in rb])

    def test_actual_engine_emitted_calibration_statistics_per_graph(self):
        for graph in r.GRAPHS:
            for mode in r.contract.MODES:
                for arm in r.contract.ARMS[1:]:
                    with self.subTest(graph=graph, mode=mode, arm=arm):
                        spec = r.contract.build_wiring(mode).arm(arm)
                        u = self.unit(graph, arm, 'none')
                        observed = set()
                        traces = list(self.platform._simulate_chunk([u], spec, self.s, 2.,
                            collect=lambda stats, attempts, active: observed.update(stats)))
                        self.assertEqual(observed, r.contract.expected_statistics(arm, mode))
                        for _, trace, _ in traces:
                            self.assertEqual(int(trace.violations.sum()), 0)


if __name__ == '__main__':
    unittest.main()
