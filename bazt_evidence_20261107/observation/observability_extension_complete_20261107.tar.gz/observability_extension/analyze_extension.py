"""Report both fixed extension graphs; no topology selection or LLM access."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import run_extension as run
sys.path.insert(0, str(run.ORIGINAL))
import analyze_mock as old


def read_rows(mode, settings):
    from bazt_lab.core import public as core
    from bazt_lab.features.runner.public import unit_id
    root = run.OUTPUT / 'evaluation' / mode / run.PROFILE / 'mock_frontier'
    files, orphans = core.committed_row_files(root)
    run.contract.require(orphans == 0, 'Uncommitted rows in extension')
    expected = {unit_id(u): u for u in run.settings_gate(settings)}
    rows = {}
    for p in files:
        raw = p.read_bytes()
        run.contract.require(not raw or raw.endswith(b'\n'), 'Truncated row file')
        for line in raw.splitlines():
            row = json.loads(line)
            uid = row['id']
            run.contract.require(uid in expected and uid not in rows, 'Unexpected or duplicate row')
            run.contract.require(all(row[k] == v for k, v in expected[uid].items()), 'Native unit identity changed')
            run.contract.require(row['violations'] == 0, 'Budget violation')
            metrics = ('accuracy_clean',) if row['attack'] == 'none' else ('asr_final', 'accuracy_clean_reference')
            run.contract.require(all(np.isfinite(row[m]) and 0 <= row[m] <= 1 for m in metrics), 'Invalid endpoint')
            rows[uid] = row
    run.contract.require(set(rows) == set(expected) and len(rows) == 12960, 'Incomplete extension grid')
    return rows, dict(records=len(rows), files=len(files), orphans=orphans,
                      committed_files_sha256={str(p.relative_to(root)): run.digest(p) for p in files})


def graph_vector(rows, topology, seeds, arms, budget, metric):
    filtered = {k: r for k, r in rows.items() if r['topology'] == topology}
    return old.vector(filtered, seeds, arms, budget, metric)


def describe(values, indices):
    return dict(mean=float(values.mean()), ci95_pointwise=old.interval(values[indices].mean(1)),
                seed_differences=values.tolist(), inferential_test=False)


def holm2(contrasts):
    run.contract.require(len(contrasts) == 2, 'Exactly two fixed extension contrasts')
    order = sorted(range(2), key=lambda j: contrasts[j]['p_two_sided'])
    previous = 0.
    for rank, j in enumerate(order):
        previous = max(previous, min(1., (2 - rank) * contrasts[j]['p_two_sided']))
        contrasts[j]['p_holm_two_graphs'] = previous
    return contrasts


def analyze():
    from bazt_lab.core import public as core
    settings = core.load_settings(run.SETTINGS)
    run.settings_gate(settings)
    gates = run.compare_calibrations()
    data, coverage = {}, {}
    for mode in run.contract.MODES:
        run.verify_frozen('evaluation', mode)
        run.verify_frozen('calibration', mode)
        data[mode], coverage[mode] = read_rows(mode, settings)
    controls = old.negative_controls(data['native_mock'], data['paid_only'])
    seeds = list(range(742001, 742031))
    indices = np.random.default_rng(old.SEED).integers(0, len(seeds), size=(20000, len(seeds)))
    contrasts, descriptive, outcomes = [], {}, {}
    for graph in run.GRAPHS:
        vectors = {}
        outcomes[graph] = {}
        for mode in run.contract.MODES:
            outcomes[graph][mode] = {}
            for label, budget, arms in [('capped', .1, old.CAPPED), ('uncapped', 'uncapped', old.UNCAPPED)]:
                outcomes[graph][mode][label] = {}
                for metric in old.METRICS:
                    arr = graph_vector(data[mode], graph, seeds, arms, budget, metric)
                    vectors[mode, label, metric] = arr
                    outcomes[graph][mode][label][metric] = dict(arms=arms, seed_means=arr.tolist(),
                        mean=arr.mean(0).tolist(), mean_ci95_pointwise=old.interval(arr[indices].mean(1)))
        free = vectors['native_mock', 'capped', 'excess_error']
        paid = vectors['paid_only', 'capped', 'excess_error']
        gf, gp = free[:, 1] - free[:, 0], paid[:, 1] - paid[:, 0]
        contrast = dict(topology=graph, secondary_predeclared_extension=True,
                        **old.contrast(gp - gf, indices))
        contrast.update(native_BAZT_minus_C=describe(gf, indices), paid_BAZT_minus_C=describe(gp, indices))
        contrasts.append(contrast)
        descriptive[graph] = []
        for label, arm in [('capped', 'BAZT_upstream'), ('uncapped', 'BAZT'), ('uncapped', 'BAZT_upstream')]:
            arms = old.CAPPED if label == 'capped' else old.UNCAPPED
            j, k = arms.index(arm), arms.index('C')
            f, p = vectors['native_mock', label, 'excess_error'], vectors['paid_only', label, 'excess_error']
            descriptive[graph].append(dict(arm=arm, budget=label,
                **describe((p[:, j] - p[:, k]) - (f[:, j] - f[:, k]), indices)))
    output = dict(study='fixed_two_graph_exploratory_extension', graphs=list(run.GRAPHS),
        independent_seeds=seeds, coverage=coverage, negative_controls=controls,
        calibration_gates=gates, secondary_core_contrasts_holm2=holm2(contrasts),
        descriptive_other_contrasts=descriptive, graph_outcomes=outcomes,
        read_llm_performance_before_extension=True, BA_heldout_already_observed=True,
        no_original_H_topology_confirmation=True,
        interpretation='Interface-plus-recalibration diagnostic; both graphs retained. Original BA and global H-budget unchanged.',
        clean_reference='attacked-row accuracy_clean_reference matches victims; utility uses independent attack-free accuracy_clean',
        sources_sha256={p.name: run.digest(p) for p in
                       [Path(__file__), Path(run.__file__), run.HERE / 'DECISIONS.json', run.HERE / 'PROTOCOL.md']})
    target = run.OUTPUT / 'analysis' / 'extension_analysis.json'
    run.write_json(target, output)
    print(json.dumps(dict(file=str(target), sha256=run.digest(target),
                         secondary_core_contrasts_holm2=output['secondary_core_contrasts_holm2']), sort_keys=True))
    return output


if __name__ == '__main__':
    analyze()
