"""CPU-only paired interface audit using the unchanged native mock engine."""
import argparse
import dataclasses
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time

import monitor_contract as contract

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent/'source'
OUTPUT=HERE/'results_20261107'

def aligned_frontier(settings,strict):
    from bazt_lab.features.runner.private.units import units_mock_frontier
    grid=units_mock_frontier(settings,strict)
    # Subset only; no unit fields/arm names/IDs are changed by interface mode.
    return dataclasses.replace(grid,arms_cells=[x for x in grid.arms_cells if x[1][0]==x[1][1]])

def install_grid():
    from bazt_lab.features.runner.private.blocks import BLOCKS
    BLOCKS['mock_frontier']=dataclasses.replace(BLOCKS['mock_frontier'],units=aligned_frontier)

def calibration_gate(path,mode):
    d=json.loads(Path(path).read_text()); cells=d['cells']
    expected={('B','barabasi_albert',12),('C','barabasi_albert',12),
        ('BAZT','barabasi_albert',12),('BAZT_upstream','barabasi_albert',12)}
    keys=[(c['arm'],c['topology'],c['agents']) for c in cells]
    contract.require(len(keys)==4 and set(keys)==expected,'Incomplete/duplicate calibration cells')
    for c in cells:
        contract.validate_thresholds(c['arm'],mode,c['thresholds'])
        rate=c['diagnostics']['rate']
        contract.require(0<=rate<=.022,'Calibration exceeds the frozen empirical ceiling')
    return dict(passed=True,mode=mode,cells=cells,
        flagged=[c for c in cells if not c['diagnostics']['within_tolerance']],
        thresholds_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest())

def path_for(phase,mode):
    return OUTPUT/phase/mode/'cpu_mock_proposed'/'mock_calibration'/'thresholds.json'

def run(phase,mode):
    from bazt_lab.core import public as core
    from bazt_lab.features.runner.public import main
    settings_path=HERE/('development.toml' if phase=='development' else 'heldout.toml')
    result=OUTPUT/phase/mode
    manifest=contract.bind_output_root(result,mode,settings_path,ROOT)
    extra=dict(runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        protocol_sha256=hashlib.sha256((HERE/'PROTOCOL.md').read_bytes()).hexdigest(),
        decisions_sha256=hashlib.sha256((HERE/'DECISIONS.json').read_bytes()).hexdigest(),
        phase=phase,read_llm_performance=False,provider_calls=0)
    frozen=result/'RUNNER_FREEZE.json'
    if frozen.exists():contract.require(json.loads(frozen.read_text())==extra,'Runner/decision source changed')
    else:frozen.write_text(json.dumps(extra,indent=2)+'\n')
    if phase!='calibration':
        gate=calibration_gate(path_for('calibration',mode),mode)
        target=path_for(phase,mode);target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():contract.require(target.read_bytes()==path_for('calibration',mode).read_bytes(),'Threshold drift')
        else:shutil.copy2(path_for('calibration',mode),target)
    install_grid()
    code=main(['--settings',str(settings_path),'--run','--block',
        'mock_calibration' if phase=='calibration' else 'mock_frontier',
        '--results-root',str(result)],wiring=contract.build_wiring(mode))
    if code:raise RuntimeError('Native runner returned nonzero status')
    if phase=='calibration':
        (result/'CALIBRATION_GATE.json').write_text(json.dumps(calibration_gate(path_for(phase,mode),mode),indent=2)+'\n')
    return manifest

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['calibration','development','heldout'])
    p.add_argument('mode',choices=contract.MODES);a=p.parse_args();run(a.phase,a.mode)
