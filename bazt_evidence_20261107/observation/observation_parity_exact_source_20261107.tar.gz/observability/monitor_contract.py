"""Mock-only observation contract intervention; never launches on import.

Native arm names and ctx.unit_ids remain unchanged across modes. Use separate
output roots with an interface manifest, NOT arm aliases or unit annotations.
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
from pathlib import Path

MODES = ("native_mock", "paid_only")
ARMS = ("A", "B", "C", "BAZT", "BAZT_upstream")
VERSION = "observability-audit-draft-v1"
BASE_STATISTICS = {
    "A": set(), "B": {"judge"}, "C": {"rl_minus_ts"},
    "BAZT": {"judge", "rl_minus_ts"}, "BAZT_upstream": {"upstream_judge"},
}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def expected_statistics(arm, mode):
    require(mode in MODES and arm in ARMS, "Unknown arm or observation mode")
    keys = set(BASE_STATISTICS[arm])
    if arm == "BAZT" and mode == "native_mock":
        keys.add("bazt_risk")
    return keys


def validate_thresholds(arm, mode, thresholds):
    import math
    require(set(thresholds) == expected_statistics(arm, mode),
            "Calibration must use statistics actually emitted under this interface")
    require(all(isinstance(v, (int, float)) and not isinstance(v, bool)
                and math.isfinite(v) for v in thresholds.values()),
            "Non-finite calibration threshold")


class ObservationControlled:
    """Delegate every native decision, changing only whether monitor is supplied."""
    def __init__(self, factory, mode):
        require(mode in MODES, "Unknown observation mode")
        self.inner = factory()
        require(getattr(self.inner, "name", "") in ARMS, "Only the five fixed arms are allowed")
        self.mode = mode
        self.rounds_observed = 0

    @property
    def name(self):
        return self.inner.name

    def reset(self, ctx):
        self.rounds_observed = 0
        self.batch_size = len(getattr(ctx, "unit_ids", (None,)))
        # Deliberately do not rename the arm or change ctx.unit_ids: native
        # policy jitter uses the full unit identity.
        self.inner.reset(ctx)

    def state_dict(self):
        return {"observation_contract": VERSION, "mode": self.mode,
                "rounds_observed": self.rounds_observed,
                "native_state": self.inner.state_dict()}

    def load_state_dict(self, state):
        require(state.get("observation_contract") == VERSION and state.get("mode") == self.mode,
                "Cannot restore a policy checkpoint from another observation contract")
        self.inner.load_state_dict(state["native_state"])
        self.rounds_observed = int(state["rounds_observed"])

    def decide(self, obs):
        require(obs.oracle is None, "This comparison never permits infection truth")
        if self.mode == "paid_only":
            view = dataclasses.replace(obs, monitor=None)
        else:
            view = obs
        require(view.audit is obs.audit and view.audit_isolated is obs.audit_isolated,
                "Paid auditor callbacks must be forwarded without replacement")
        require(view.remaining_audit is obs.remaining_audit and
                view.remaining_intervention is obs.remaining_intervention,
                "The interface intervention may not alter budget ledgers")
        action = self.inner.decide(view)
        self.rounds_observed += 1
        # Derivative provenance; native action fields/statistics remain intact.
        for b in range(getattr(self, "batch_size", 1)):
            action.events.append({"event": "observability_contract", "mode": self.mode,
                                  "monitor_supplied": view.monitor is not None,
                                  "oracle_supplied": False,
                                  "paid_callbacks_forwarded": True, "t": int(obs.t), "b": b})
        return action


def build_wiring(mode):
    """Lazy imports: constructing the draft never imports a provider backend."""
    require(mode in MODES, "Unknown observation mode")
    from bazt_lab.app import build_wiring as original
    base = original()

    def arm(name):
        require(name in ARMS, "Only the five frozen headline arms are allowed")
        spec = base.arm(name)
        require(not spec.needs_truth, "No oracle information in the interface audit")
        factory = spec.factory
        return dataclasses.replace(spec,
            factory=lambda: ObservationControlled(factory, mode), platforms=("mock",))

    def platform(name):
        require(name == "mock", "This draft cannot construct an LLM/provider platform")
        return base.platform(name)

    rebuild = (__name__ + ":build_native_mock" if mode == "native_mock"
               else __name__ + ":build_paid_only")
    return dataclasses.replace(base, arm=arm, platform=platform, rebuild=rebuild)


def build_native_mock():
    return build_wiring("native_mock")


def build_paid_only():
    return build_wiring("paid_only")


def source_manifest(repository_root):
    root = Path(repository_root)
    require(all((root / name).is_dir() and any((root / name).rglob("*.py"))
                for name in ("bazt_lab", "bazt")), "Missing scientific source directories")
    selected = [p for name in ("bazt_lab", "bazt") for p in (root / name).rglob("*.py")]
    selected += [root / p for p in ("swarmlab.py", "llm_client.py")]
    require(selected and all(p.is_file() for p in selected), "Missing scientific source files")
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(selected)}


def bind_output_root(results_root, mode, settings_path, repository_root):
    """Separate outer identity because native threshold_view does not encode this wrapper.

    Call before calibration/evaluation. A caller must still run the native
    clean calibration and check its empirical FPR before attacked evaluation.
    """
    require(mode in MODES, "Unknown observation mode")
    root = Path(results_root)
    root.mkdir(parents=True, exist_ok=True)
    manifest = {
        "status": "draft_interface_bound_not_experiment_complete", "version": VERSION,
        "mode": mode, "monitor": "native_mock" if mode == "native_mock" else None,
        "arms": list(ARMS), "oracle": False, "audit_callbacks": "unchanged_native_paid",
        "settings_sha256": hashlib.sha256(Path(settings_path).read_bytes()).hexdigest(),
        "source_sha256": source_manifest(repository_root),
        "wrapper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "pairing": "same unit IDs and arm names in distinct output roots",
    }
    path = root / "OBSERVABILITY_INTERFACE.json"
    if path.exists():
        require(json.loads(path.read_text()) == manifest,
                "Output root belongs to a different interface/settings/source identity")
    else:
        require(not any(root.iterdir()), "Refusing an unmanifested nonempty results root")
        path.write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n")
    return manifest
