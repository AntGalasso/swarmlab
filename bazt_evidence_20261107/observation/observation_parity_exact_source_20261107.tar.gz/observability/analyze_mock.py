"""Mock-only paired analysis and prediction record; cannot read LLM outcomes."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from bazt_lab.core import public as core
from bazt_lab.features.runner.public import unit_id
import monitor_contract as c
import run_observability as run

SEED=202611071733
METRICS=['excess_error','ASR_final','accuracy_clean']
CAPPED=['C','BAZT','BAZT_upstream']
UNCAPPED=['A','B','C','BAZT','BAZT_upstream']

def read_rows(phase,mode,settings):
    root=run.OUTPUT/phase/mode/'cpu_mock_proposed'/'mock_frontier'
    files,orphans=core.committed_row_files(root)
    c.require(orphans==0,'Uncommitted scientific rows')
    expected={unit_id(u):u for u in run.aligned_frontier(settings,True)}
    rows={}
    for p in files:
        for line in p.read_text().splitlines():
            row=json.loads(line);uid=row['id']
            c.require(uid in expected and uid not in rows,'Unexpected or duplicate row')
            c.require(all(row[k]==v for k,v in expected[uid].items()),'Native unit identity changed')
            c.require(row['violations']==0,'Budget violation')
            if row['attack']=='none':c.require(np.isfinite(row['accuracy_clean']),'Missing clean accuracy')
            else:
                c.require(np.isfinite(row['asr_final']) and np.isfinite(row['accuracy_clean_reference']),
                    'Missing attack or matched victim-population clean reference')
            rows[uid]=row
    c.require(set(rows)==set(expected),'Incomplete grid')
    return rows,dict(records=len(rows),files=len(files),orphans=orphans,
        committed_files_sha256={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files})

def scientific_row(row):
    row=dict(row)
    row['meta_events']=[e for e in row.get('meta_events',[]) if e.get('event')!='observability_contract']
    return json.dumps(row,sort_keys=True)

def negative_controls(a,b):
    c.require(set(a)==set(b),'Mode grids differ')
    checked=0
    for uid,row in a.items():
        if row['arm'] in ['A','B','C']:
            c.require(scientific_row(row)==scientific_row(b[uid]),'Negative control changed: '+uid)
            checked+=1
    return dict(passed=True,rows_bit_identical_except_declared_events=checked)

def vector(rows,seeds,arms,budget,metric):
    out=[]
    for seed in seeds:
        cells=[]
        for arm in arms:
            selected=[r for r in rows.values() if r['seed']==seed and r['arm']==arm
                and r['audit']==budget and r['intervention']==budget
                and r['attack']==('none' if metric=='accuracy_clean' else 'insider_pi')]
            c.require(len(selected)==12 and {r['sink'] for r in selected}==set(range(12)),'Incomplete seed/sink cell')
            if metric=='accuracy_clean':values=[r['accuracy_clean'] for r in selected]
            elif metric=='ASR_final':values=[r['asr_final'] for r in selected]
            else:values=[r['asr_final']-(1-r['accuracy_clean_reference']) for r in selected]
            cells.append(float(np.mean(values)))
        out.append(cells)
    return np.array(out,dtype=float)

def ranks(x):
    # Rank1 is smallest; ties use the predeclared1e-12 equality tolerance.
    x=np.asarray(x)
    less=(x[...,None,:]<x[...,:,None]-1e-12).sum(-1)
    tied=(np.abs(x[...,None,:]-x[...,:,None])<=1e-12).sum(-1)
    return 1+less+.5*(tied-1)

def interval(x):return np.quantile(x,[.025,.975],axis=0).tolist()

def signflip(x):
    rng=np.random.default_rng(SEED)
    signs=rng.integers(0,2,size=(100000,len(x)),dtype=np.int8)*2-1
    statistic=np.abs((signs*x).mean(1))
    return float((np.count_nonzero(statistic>=abs(x.mean())-1e-14)+1)/100001)

def contrast(x,indices):
    means=x[indices].mean(1)
    return dict(mean=float(x.mean()),ci95=interval(means),p_two_sided=signflip(x),seed_differences=x.tolist())

def analyze(phase):
    settings=core.load_settings(run.HERE/('development.toml' if phase=='development' else 'heldout.toml'))
    lo,hi=settings['mock']['main_seeds'];seeds=list(range(lo,hi+1))
    data={};coverage={}
    for mode in c.MODES:data[mode],coverage[mode]=read_rows(phase,mode,settings)
    controls=negative_controls(data['native_mock'],data['paid_only'])
    gates={mode:run.calibration_gate(run.path_for('calibration',mode),mode) for mode in c.MODES}
    for arm in ['B','C']:
        th=[next(x['thresholds'] for x in gates[m]['cells'] if x['arm']==arm) for m in c.MODES]
        c.require(th[0]==th[1],'Negative-control calibration differs')
    indices=np.random.default_rng(SEED).integers(0,len(seeds),size=(20000,len(seeds)))
    vectors={};predictions={}
    for mode in c.MODES:
        predictions[mode]={}
        for label,budget,arms in [('capped',.1,CAPPED),('uncapped','uncapped',UNCAPPED)]:
            predictions[mode][label]={}
            for metric in METRICS:
                arr=vector(data[mode],seeds,arms,budget,metric);vectors[mode,label,metric]=arr
                boot=arr[indices].mean(1)
                signed=boot*(-1 if metric=='accuracy_clean' else 1)
                rs=ranks(signed);point=ranks(arr.mean(0)*(-1 if metric=='accuracy_clean' else 1))
                best=rs==rs.min(1,keepdims=True)
                predictions[mode][label][metric]=dict(arms=arms,mean=arr.mean(0).tolist(),
                    mean_ci95=interval(boot),point_average_ranks=point.tolist(),rank_ci95=interval(rs),
                    best_or_tied_best_probability=best.mean(0).tolist(),seed_means=arr.tolist())
    free=vectors['native_mock','capped','excess_error'];paid=vectors['paid_only','capped','excess_error']
    gf=free[:,1]-free[:,0];gp=paid[:,1]-paid[:,0];difference=gp-gf
    primary=contrast(difference,indices)
    primary.update(native_BAZT_minus_C=contrast(gf,indices),paid_BAZT_minus_C=contrast(gp,indices))
    winner=lambda x:set(np.flatnonzero(np.isclose(x.mean(0),x.mean(0).min(),rtol=0,atol=1e-12)).tolist())
    flip=bool(gf.mean()*gp.mean()<0);change=winner(free).isdisjoint(winner(paid))
    practical=bool(abs(difference.mean())>=.05)
    primary.update(signed_comparative_flip=flip,disjoint_best_arm_sets=change,
        minimum_practical_change_met=practical,
        development_promotion=bool(practical and (flip or change)))
    secondary=[]
    for label,arm in [('capped','BAZT_upstream'),('uncapped','BAZT'),('uncapped','BAZT_upstream')]:
        arms=CAPPED if label=='capped' else UNCAPPED;j=arms.index(arm);k=arms.index('C')
        f=vectors['native_mock',label,'excess_error'];p=vectors['paid_only',label,'excess_error']
        secondary.append(dict(arm=arm,budget=label,**contrast((p[:,j]-p[:,k])-(f[:,j]-f[:,k]),indices)))
    order=np.argsort([x['p_two_sided'] for x in secondary]);last=0
    for rank,j in enumerate(order):
        last=max(last,min(1.,secondary[j]['p_two_sided']*(3-rank)));secondary[j]['p_holm']=last
    output=dict(phase=phase,independent_seeds=seeds,coverage=coverage,negative_controls=controls,
        calibration_gates=gates,primary=primary,secondary_holm3=secondary,mock_predictions=predictions,
        no_LLM_outcomes_accessed=True,interpretation='New diagnostic; original H-budget global null unchanged',
        clean_reference='attacked-row accuracy_clean_reference uses the same non-insider victims; utility ranks use attack-free accuracy_clean',
        source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),run.HERE/'DECISIONS.json',run.HERE/'METRIC_CONTRACT.json']})
    directory=run.OUTPUT/'analysis';directory.mkdir(exist_ok=True)
    path=directory/(phase+'_mock_analysis.json');path.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(phase=phase,independent_seeds=len(seeds),primary=primary,
        file=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest())))
    return output

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['development','heldout'])
    analyze(p.parse_args().phase)
