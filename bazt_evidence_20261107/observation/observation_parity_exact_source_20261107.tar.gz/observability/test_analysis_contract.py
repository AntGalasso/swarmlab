import unittest
import numpy as np
import analyze_mock as a

class AnalysisContract(unittest.TestCase):
    def test_ties_use_average_rank(self):
        np.testing.assert_array_equal(a.ranks(np.array([1.,1.,3.])),[1.5,1.5,3.])

    def test_primary_uses_matched_victims_not_clean_all_agent_floor(self):
        rows={}
        for sink in range(12):
            base=dict(seed=1,arm='C',audit=.1,intervention=.1,sink=sink)
            rows['attack'+str(sink)]={**base,'attack':'insider_pi','asr_final':.5,'accuracy_clean_reference':.8}
            rows['clean'+str(sink)]={**base,'attack':'none','accuracy_clean':.2}
        np.testing.assert_allclose(a.vector(rows,[1],['C'],.1,'excess_error'),[[.3]])
        np.testing.assert_allclose(a.vector(rows,[1],['C'],.1,'accuracy_clean'),[[.2]])

    def test_negative_controls_ignore_only_interface_provenance(self):
        row=dict(arm='C',id='same',spend_total=2,meta_events=[{'event':'observability_contract','mode':'native_mock'}])
        other={**row,'meta_events':[{'event':'observability_contract','mode':'paid_only'}]}
        self.assertTrue(a.negative_controls({'same':row},{'same':other})['passed'])
        with self.assertRaises(RuntimeError):a.negative_controls({'same':row},{'same':{**other,'spend_total':3}})

    def test_zero_paired_effect_is_not_significant(self):
        self.assertEqual(a.signflip(np.zeros(12)),1.)

if __name__=='__main__':unittest.main()
