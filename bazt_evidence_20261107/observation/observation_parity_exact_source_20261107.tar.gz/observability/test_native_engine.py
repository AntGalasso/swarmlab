"""Actual mock-engine interface, negative-control, accounting and state checks."""
import copy
import dataclasses
import json
from pathlib import Path
import tempfile
import unittest
import torch

import monitor_contract as m
import run_observability as r
from bazt_lab.core import public as core
from bazt_lab.features.mock_engine.public import MockPlatform
from bazt_lab.features.runner.public import unit_id
from bazt_lab.app import build_wiring

class Tracked(m.ObservationControlled):
    def reset(self,ctx):
        self.last_ctx=ctx
        super().reset(ctx)

def equal(test,left,right):
    if isinstance(left,torch.Tensor):
        torch.testing.assert_close(left,right,rtol=0,atol=0,equal_nan=True)
    elif isinstance(left,dict):
        test.assertEqual(set(left),set(right))
        for k in left:equal(test,left[k],right[k])
    elif isinstance(left,(list,tuple)):
        test.assertEqual(len(left),len(right))
        for a,b in zip(left,right):equal(test,a,b)
    else:test.assertEqual(left,right)

class NativeEngineTests(unittest.TestCase):
    def setUp(self):
        self.s=core.load_settings(r.HERE/'development.toml')
        self.base=build_wiring()
        self.platform=MockPlatform()
        self.units=list(r.aligned_frontier(self.s,True))

    def unit(self,arm,thresholds):
        u=copy.deepcopy(next(u for u in self.units if u['arm']==arm and u['attack']=='insider_pi'
            and u['sink']==0 and (arm=='A' or u['audit']==.1)))
        u.update(id=unit_id(u),thresholds=thresholds)
        u['twin_id']=unit_id({**u,'attack':'none'})
        return u

    def simulate(self,arm,mode,thresholds):
        instances=[]
        original=self.base.arm(arm)
        def factory():
            obj=Tracked(original.factory,mode);instances.append(obj);return obj
        spec=dataclasses.replace(original,factory=factory)
        unit=self.unit(arm,thresholds)
        traces=list(self.platform._simulate_chunk([unit],spec,self.s,2.,with_clean=True))
        self.assertTrue(traces)
        for obj in instances:
            state=copy.deepcopy(obj.state_dict())
            resumed=Tracked(original.factory,mode);resumed.reset(obj.last_ctx);resumed.load_state_dict(state)
            equal(self,state,resumed.state_dict())
        return traces,instances

    def test_actual_engine_negative_controls_are_bit_identical(self):
        for arm,thresholds in [('A',{}),('B',{'judge':1.}),('C',{'rl_minus_ts':0.})]:
            with self.subTest(arm=arm):
                a,_=self.simulate(arm,'native_mock',thresholds)
                b,_=self.simulate(arm,'paid_only',thresholds)
                for (_,ta,_),(_,tb,_) in zip(a,b):
                    self.assertEqual(ta.unit_ids,tb.unit_ids)
                    for field in dataclasses.fields(ta):
                        if field.name=='meta':continue
                        equal(self,getattr(ta,field.name),getattr(tb,field.name))
                    ra=self.platform._rows(ta,self.s);rb=self.platform._rows(tb,self.s)
                    for row in ra+rb:
                        row['meta_events']=[e for e in row.get('meta_events',[]) if e.get('event')!='observability_contract']
                    self.assertEqual(json.dumps(ra,sort_keys=True),json.dumps(rb,sort_keys=True))

    def test_bazt_actual_emitted_keys_paid_audits_and_state(self):
        for mode in m.MODES:
            for arm in ['BAZT','BAZT_upstream']:
                with self.subTest(mode=mode,arm=arm):
                    spec=m.build_wiring(mode).arm(arm)
                    unit=self.unit(arm,{})
                    unit.update(attack='none',id=unit_id({**unit,'attack':'none'}))
                    observed=set()
                    traces=list(self.platform._simulate_chunk([unit],spec,self.s,2.,
                        collect=lambda statistics,attempts,active:observed.update(statistics)))
                    self.assertEqual(observed,m.expected_statistics(arm,mode))
                    thresholds={k:1. for k in observed}
                    simulated,instances=self.simulate(arm,mode,thresholds)
                    for _,trace,_ in simulated:
                        self.assertEqual(int(trace.violations.sum()),0)
                        cap=instances[0].last_ctx.audit_cap
                        self.assertTrue(bool((trace.spend_audit.sum(1)<=cap+1e-8).all()))
                        self.assertTrue(bool((trace.spend_intervention.sum(1)<=instances[0].last_ctx.intervention_cap+1e-8).all()))
                        inspect_index=list(core.ActionKind).index(core.ActionKind.INSPECT)
                        torch.testing.assert_close(trace.spend_audit.sum(1),trace.action_counts[:,inspect_index].double(),rtol=0,atol=0)

    def test_complete_unit_resume_adds_no_rows(self):
        with tempfile.TemporaryDirectory() as d:
            store=core.CheckpointStore(Path(d))
            spec=m.build_wiring('paid_only').arm('C')
            u=self.unit('C',{'rl_minus_ts':0.})
            first=self.platform.run_batch([u],spec,self.s,store,core.NullTracker())
            before={str(p.relative_to(d)):p.read_bytes() for p in Path(d).rglob('*') if p.is_file()}
            second=self.platform.run_batch([u],spec,self.s,store,core.NullTracker())
            self.assertEqual(len(first),1);self.assertEqual(second,[])
            self.assertEqual(before,{str(p.relative_to(d)):p.read_bytes() for p in Path(d).rglob('*') if p.is_file()})

    def test_real_batch_has_one_attributable_provenance_event_per_episode_round(self):
        for mode in m.MODES:
            arm=m.build_wiring(mode).arm('C')
            group=[copy.deepcopy(u) for u in self.units if u['arm']=='C' and u['attack']=='none'
                and u['audit']==.1][:4]
            for u in group:u.update(id=unit_id(u),thresholds={'rl_minus_ts':0.})
            traces=list(self.platform._simulate_chunk(group,arm,self.s,2.))
            rows=[r for _,trace,_ in traces for r in self.platform._rows(trace,self.s)]
            self.assertEqual(len(rows),4)
            for row in rows:
                events=[e for e in row['meta_events'] if e.get('event')=='observability_contract']
                self.assertEqual(len(events),row['n_rounds'])
                self.assertTrue(all(e['mode']==mode for e in events))

if __name__=='__main__':unittest.main()
