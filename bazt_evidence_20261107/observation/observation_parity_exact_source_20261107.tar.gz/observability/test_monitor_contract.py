"""Stdlib proxy checks only: these do NOT substitute for native-engine validation."""
import dataclasses
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).parent))
import monitor_contract as m


@dataclasses.dataclass
class Obs:
    monitor: object
    audit: object
    remaining_audit: object
    remaining_intervention: object
    audit_isolated: object = None
    oracle: object = None
    t: int = 1


@dataclasses.dataclass
class Action:
    events: list = dataclasses.field(default_factory=list)


class Inner:
    name = "BAZT"
    def reset(self, ctx): self.ctx = ctx
    def state_dict(self): return {"x": 7}
    def load_state_dict(self, state): self.loaded = state
    def decide(self, obs): self.seen = obs; return Action()


class ContractTests(unittest.TestCase):
    def test_only_monitor_is_changed_and_ids_are_not_renamed(self):
        p = m.ObservationControlled(Inner, "paid_only")
        ctx = object(); p.reset(ctx)
        obs = Obs(object(), object(), object(), object(), object())
        p.decide(obs)
        self.assertIs(p.inner.ctx, ctx)
        self.assertEqual(p.name, "BAZT")
        self.assertIsNone(p.inner.seen.monitor)
        for k in ["audit", "audit_isolated", "remaining_audit", "remaining_intervention"]:
            self.assertIs(getattr(p.inner.seen, k), getattr(obs, k))
        self.assertIsNotNone(obs.monitor)

    def test_native_mode_forwards_identical_observation(self):
        p = m.ObservationControlled(Inner, "native_mock")
        obs = Obs(object(), object(), object(), object())
        p.decide(obs)
        self.assertIs(p.inner.seen, obs)

    def test_oracle_and_cross_mode_checkpoint_are_refused(self):
        p = m.ObservationControlled(Inner, "paid_only")
        with self.assertRaises(RuntimeError):
            p.decide(Obs(None, object(), object(), object(), oracle=lambda: True))
        p.decide(Obs(None, object(), object(), object()))
        state = p.state_dict()
        q = m.ObservationControlled(Inner, "paid_only"); q.load_state_dict(state)
        self.assertEqual(q.rounds_observed, 1)
        with self.assertRaises(RuntimeError):
            m.ObservationControlled(Inner, "native_mock").load_state_dict(state)

    def test_calibration_keys_are_emitted_interface_keys_not_deleted_afterward(self):
        m.validate_thresholds("BAZT", "paid_only", {"judge": 1., "rl_minus_ts": 2.})
        with self.assertRaises(RuntimeError):
            m.validate_thresholds("BAZT", "paid_only", {"judge": 1., "rl_minus_ts": 2., "bazt_risk": 3.})
        m.validate_thresholds("BAZT", "native_mock", {"judge": 1., "rl_minus_ts": 2., "bazt_risk": 3.})


if __name__ == "__main__":
    unittest.main()
